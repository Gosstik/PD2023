#! /usr/bin/env bash

hive -f query.sql
