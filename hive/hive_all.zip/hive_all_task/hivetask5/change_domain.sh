#! /usr/bin/env bash

sed 's/.ru\//.com\//g'
