DROP DATABASE IF EXISTS vashkevicheg cascade;

CREATE DATABASE vashkevicheg
LOCATION '/user/pd2023a024/hive_hw';

--------------------------------------------------------------------------------

DROP DATABASE IF EXISTS pd2023a024_test cascade;

CREATE DATABASE pd2023a024_test
LOCATION '/user/pd2023a024/hive_hw_test';

--------------------------------------------------------------------------------

